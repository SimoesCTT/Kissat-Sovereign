from setuptools import setup, find_packages

setup(
    name="kissat-sovereign",
    version="1.0.4",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "sovereign_pkg": ["*.so"],
    },
    entry_points={
        "console_scripts": [
            "kissat-sovereign=sovereign_pkg.engine:solve_sovereign_cli",
        ],
    },
)
